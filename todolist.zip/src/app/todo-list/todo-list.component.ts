import { Component, OnInit } from '@angular/core';
import {TodoListService} from './todo-list.service'
import {Todo} from '../Todo'
@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss']
})
export class TodoListComponent implements OnInit {
  private lists:Todo[];
  statusList = [
    {display: 'Pending', value: 'pending'},
    {display: 'Doing', value: 'doing'},
    {display: 'Completed', value: 'completed'},
  ];
  constructor(private todolist:TodoListService) { }

  ngOnInit() {
    this.lists =this.todolist.getTodos()
  }
  deleteImage(index)
  {
    this.lists.splice(index, 1);
  }

}
